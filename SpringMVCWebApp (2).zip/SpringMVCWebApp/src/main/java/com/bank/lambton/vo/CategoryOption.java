/* Date -@07-08-2021
Author - @Dhara vegad, Priyal patel
Description - this is category class
*/

package com.bank.lambton.vo;

public class CategoryOption {
	private int id;
	private int categoryId;
	private String title;
	private String inputName;
	private String inputType;

	public int getId(){
	return id;
	}

	public void setId(int id){
	this.id=id;
	}

	public int getCategoryId(){
	return categoryId;
	}

	public void setCategoryId(int categoryId){
	this.categoryId=categoryId;
	}

	public String getTitle(){
	return title;
	}

	public void setTitle(String title){
	this.title=title;
	}

	public String getInputName(){
	return inputName;
	}

	public void setInputName(String inputName){
	this.inputName=inputName;
	}

	public String getInputType(){
	return inputType;
	}

	public void setInputType(String inputType){
	this.inputType=inputType;
	}

	}

